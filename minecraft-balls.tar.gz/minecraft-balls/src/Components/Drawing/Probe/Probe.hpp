//
//  Probe.hpp
//  2019_cg_physics
//
//  Created by Mariya Davidouskaya on 18.05.19.
//  Copyright © 2019 Universität Salzburg. All rights reserved.
//

#ifndef Probe_hpp
#define Probe_hpp

#include <stdio.h>

#endif /* Probe_hpp */
