//
//  Probe.cpp
//  2019_cg_physics
//
//  Created by Mariya Davidouskaya on 18.05.19.
//  Copyright © 2019 Universität Salzburg. All rights reserved.
//

#include "Probe.hpp"
