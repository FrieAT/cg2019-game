//
//  GrassBlockTexture.hpp
//  2019_cg_physics
//
//  Created by Friedrich Schmidt on 21.06.19.
//  Copyright © 2019 Universität Salzburg. All rights reserved.
//

#ifndef GrassBlockTexture_hpp
#define GrassBlockTexture_hpp

#include "SteveAbstractTexture.hpp"

class GrassBlockTexture : public SteveAbstractTexture
{
public:
    GrassBlockTexture();
};


#endif /* GrassBlockTexture_hpp */
