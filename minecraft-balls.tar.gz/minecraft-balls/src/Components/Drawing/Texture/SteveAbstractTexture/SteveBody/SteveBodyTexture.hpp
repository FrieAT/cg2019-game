//
//  SteveBodyTexture.hpp
//  2019_cg_physics
//
//  Created by Friedrich Schmidt on 11.06.19.
//  Copyright © 2019 Universität Salzburg. All rights reserved.
//

#ifndef SteveBodyTexture_hpp
#define SteveBodyTexture_hpp

#include "SteveAbstractTexture.hpp"

class SteveBodyTexture : public SteveAbstractTexture
{
public:
    SteveBodyTexture();
};


#endif /* SteveBodyTexture_hpp */
