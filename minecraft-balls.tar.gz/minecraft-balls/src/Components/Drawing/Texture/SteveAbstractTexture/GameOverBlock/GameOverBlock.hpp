//
//  GameOverBlock.hpp
//  2019_cg_physics
//
//  Created by Masud Mostafa on 26.06.19.
//  Copyright © 2019 Universität Salzburg. All rights reserved.
//

#ifndef GameOverBlock_hpp
#define GameOverBlock_hpp

#include <stdio.h>

#endif /* GameOverBlock_hpp */
