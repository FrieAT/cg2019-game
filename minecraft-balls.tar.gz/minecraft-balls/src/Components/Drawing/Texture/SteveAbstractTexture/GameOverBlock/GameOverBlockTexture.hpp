//
//  GameOverBlockTexture.hpp
//  2019_cg_physics
//
//  Created by Masud Mostafa on 26.06.19.
//  Copyright © 2019 Universität Salzburg. All rights reserved.
//

#ifndef GameOverBlockTexture_hpp
#define GameOverBlockTexture_hpp

#include "SteveAbstractTexture.hpp"

class GameOverBlockTexture : public SteveAbstractTexture
{
public:
    GameOverBlockTexture();
};

#endif /* GameOverBlockTexture_hpp */
