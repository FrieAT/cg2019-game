//
//  WoodBlockTexture.hpp
//  2019_cg_physics
//
//  Created by Friedrich Schmidt on 27.06.19.
//  Copyright © 2019 Universität Salzburg. All rights reserved.
//

#ifndef WoodBlockTexture_hpp
#define WoodBlockTexture_hpp

#include "SteveAbstractTexture.hpp"

class WoodBlockTexture : public SteveAbstractTexture
{
public:
    WoodBlockTexture();
};

#endif /* WoodBlockTexture_hpp */
