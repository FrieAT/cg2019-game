//
//  SteveLegTexture.hpp
//  2019_cg_physics
//
//  Created by Friedrich Schmidt on 11.06.19.
//  Copyright © 2019 Universität Salzburg. All rights reserved.
//

#ifndef SteveLegTexture_hpp
#define SteveLegTexture_hpp

#include "SteveAbstractTexture.hpp"

class SteveLegTexture : public SteveAbstractTexture
{
public:
    SteveLegTexture();
};

#endif /* SteveLegTexture_hpp */
