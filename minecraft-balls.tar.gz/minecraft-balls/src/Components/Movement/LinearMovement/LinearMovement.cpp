//
//  LinearMovement.cpp
//  2019_cg_physics
//
//  Created by Friedrich Schmidt on 25.05.19.
//  Copyright © 2019 Universität Salzburg. All rights reserved.
//

#include "LinearMovement.hpp"

LinearMovement::LinearMovement()
: _move(Vector3(0.0, 0.0, 0.0))
, _speed(1.0f)
{
    
}
