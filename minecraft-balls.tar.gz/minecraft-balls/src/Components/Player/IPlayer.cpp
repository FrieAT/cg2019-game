//
//  IPlayer.c
//  2019_cg_physics
//
//  Created by Friedrich Schmidt on 28.06.19.
//  Copyright © 2019 Universität Salzburg. All rights reserved.
//

#include "IPlayer.hpp"

GameObject * IPlayer::PlayerOne = nullptr;
