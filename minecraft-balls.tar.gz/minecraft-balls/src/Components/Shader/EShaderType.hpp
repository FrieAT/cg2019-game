
#pragma once

enum class EShaderType {
    VertexShader,
    FragmentShader,
    
    // ... define more shaders above this line.
    MaxItem,
};
