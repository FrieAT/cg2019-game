#include "Exception.hpp"

Exception::Exception(std::string exceptionMessage)
{
    this->_exceptionMessage = exceptionMessage;
}
