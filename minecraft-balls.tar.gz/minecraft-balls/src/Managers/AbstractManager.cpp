#include "AbstractManager.hpp"

AbstractManager::AbstractManager(const Game &engine)
: _engine(engine)
{
    
}
