#!/bin/bash
rm -r ./CMakeFiles/ 2>/dev/null
rm ./CMakeCache.txt 2>/dev/null
rm ./cmake_install.cmake 2>/dev/null
rm -r ./src/CMakeFiles/ 2>/dev/null
rm ./src/cmake_install.cmake 2>/dev/null
rm ./src/CMakeCache.txt 2>/dev/null
rm ./Makefile 2>/dev/null
rm ./src/Makefile 2>/dev/null
rm ./src/2019_cg_physics
